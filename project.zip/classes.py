from dataclasses import dataclass
from math import radians, cos, sin, asin, sqrt


@dataclass
class Cafe:
    id: int
    title: str
    cuisine: str
    avg_price: int
    district: str
    url: str
    latitude: int
    longitude: int


@dataclass
class Review:
    id: int
    review: str
    rating: float
    cafe_id: int


class Point:
    """Class for representing geographic coordinates"""
    def __init__(self, latitude=0.0, longitude=0.0):
        self.latitude = float(latitude)
        self.longitude = float(longitude)

    def __sub__(self, other):
        """Calculate distance in km between two coordinates
        
        Args:
            other: instance of class Point
        """
        # Convert coordinates from degrees to radians
        lat1 = radians(other.latitude)
        lon1 = radians(other.longitude)
        lat2 = radians(self.latitude)
        lon2 = radians(self.longitude)

        # Haversine formula
        dlon = lon2 - lon1
        dlat = lat2 - lat1
        a = sin(dlat / 2)**2 + cos(lat1) * cos(lat2) * sin(dlon / 2)**2
        c = 2 * asin(sqrt(a))
        
        # Radius of earth in kilometers
        r = 6371
        
        # calculate the result
        return c * r