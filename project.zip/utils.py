from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import CallbackContext

from replies import Templates
from classes import Cafe

import sqlite3
from typing import List


async def send_cafes(update: Update, context: CallbackContext.DEFAULT_TYPE, cursor: sqlite3.Cursor, cafes: List[Cafe]):
    for c in cafes:
        keyboard = [
            [InlineKeyboardButton("🚴‍♀️ Как добраться?", callback_data=f"[path]:{c.id}")],
            [InlineKeyboardButton("📘 Отзывы", callback_data=f"[read_reviews]:{c.id}")], 
            [InlineKeyboardButton("⭐️ Оставить отзыв", callback_data=f"[rate]:{c.id}")]
        ]
        rating = list(cursor.execute("SELECT rating FROM reviews WHERE cafe_id = ?", (c.id,)))
        if len(rating) == 0:
            rating = "-"
        else:
            rating = f"{round(sum(map(lambda x: x[0], rating)) / len(rating), 2)}/10"
        await context.bot.send_message(
            chat_id=update.effective_chat.id,
            text=Templates.CAFE_TEMPLATE.format(c.title, rating, c.url),
            reply_markup=InlineKeyboardMarkup(keyboard)
    )