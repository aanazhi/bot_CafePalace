import sqlite3
import os


TOKEN = "5279468538:AAHrsEL4ORg9E0GkLhFS49UeonwT5wDqPfI"
conn = sqlite3.connect(os.path.join("db", "cafes.db"))
