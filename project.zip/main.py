import telegram.ext.filters as filters
from telegram.ext import (
    ConversationHandler, ApplicationBuilder, 
    CommandHandler, MessageHandler,
    CallbackQueryHandler
)

from handlers.message_handlers import about_us_handler
from handlers.near_cafe_handlers import (
    location_handler, 
    nearby_cafes_handler
)
from handlers.review_conversation_handlers import (
    set_rating_handler, 
    leave_review_handler, 
    process_review_handler,
    read_reviews_handler
)
from handlers.find_cafe_conversation_handlers import (
    choose_average_price_handler,
    choose_cuisine_handler,
    choose_district_handler,
    show_cafes_handler,
    show_location_handler
)
from handlers.command_handlers import (
    start_handler
)

from constants import TOKEN

import logging


logging.basicConfig(level=logging.INFO,
                    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')


if __name__ == "__main__":
    # Build application
    app = ApplicationBuilder().token(TOKEN).build()

    # Comman handlers
    start_handler = CommandHandler("start", start_handler)

    # Callback Query handlers
    average_price_callback = CallbackQueryHandler(choose_average_price_handler)
    cuisine_callback = CallbackQueryHandler(choose_cuisine_handler)
    cafes_callback = CallbackQueryHandler(show_cafes_handler)
    set_rating_callback = CallbackQueryHandler(set_rating_handler, pattern="\[rate\]:\d+")
    read_reviews_callback = CallbackQueryHandler(read_reviews_handler, pattern="\[read_reviews\]:\d+")
    show_location_callback = CallbackQueryHandler(show_location_handler, pattern="\[path\]:\d+")

    # Message handlers
    nearby_message_handler = MessageHandler(filters.Regex("🧭 Поблизости"), nearby_cafes_handler)
    location_message_handler = MessageHandler(filters.LOCATION, location_handler)
    about_us_message_handler = MessageHandler(filters.Regex("👥 О нас"), about_us_handler)

    # Conversation handlers
    cafe_conv_handler = ConversationHandler(
        entry_points=[MessageHandler(filters.Regex("🍽 Подобрать заведение"), choose_district_handler)],
        states={
            1: [average_price_callback],
            2: [cuisine_callback],
            3: [cafes_callback]
        },
        fallbacks=[]
    )
    reviews_conv_handler = ConversationHandler(
        entry_points=[set_rating_callback],
        states={
            1: [MessageHandler(filters.Regex("\d{1,2}"), leave_review_handler)],
            2: [MessageHandler(filters.TEXT, process_review_handler)]
        },
        fallbacks=[]
    )

    # Add handlers to the application
    app.add_handler(start_handler)
    app.add_handler(cafe_conv_handler)
    app.add_handler(reviews_conv_handler)
    app.add_handler(read_reviews_callback)
    app.add_handler(show_location_callback)
    app.add_handler(location_message_handler)
    app.add_handler(nearby_message_handler)
    app.add_handler(about_us_message_handler)

    app.run_polling()
