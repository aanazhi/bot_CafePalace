from telegram import Update, KeyboardButton, ReplyKeyboardMarkup
from telegram.ext import CallbackContext

from replies import Replies

from typing import List


async def about_us_handler(update: Update, context: CallbackContext.DEFAULT_TYPE):
    """Handler which shows data about us
    
    Args:
        update: object that represents an incoming update
        context: a context object
    """
    await context.bot.send_message(
        chat_id=update.effective_chat.id,
        text=Replies.ABOUT_US
    )