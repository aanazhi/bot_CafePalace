from telegram import Update
from telegram.ext import CallbackContext, ConversationHandler

from classes import Review, Cafe
from constants import conn
from replies import Replies, Templates

from typing import List


async def set_rating_handler(update: Update, context: CallbackContext.DEFAULT_TYPE):
    """Handler that selects chosen cafe for rating
    
    Args:
        update: object that represents an incoming update
        context: a context object
    """
    # Get cafe id from callback query
    cafe_id = int(update.callback_query.data.split(":")[1])

    # Save cafe id to users' data
    context.user_data["rating_cafe_id"] = cafe_id

    # Ask user to rate cafe
    await context.bot.send_message(
        chat_id=update.effective_chat.id,
        text=Replies.CHOOSE_RATING
    )

    return 1


async def leave_review_handler(update: Update, context: CallbackContext.DEFAULT_TYPE):
    """Handler that processes rating set by user
    
    Args:
        update: object that represents an incoming update
        context: a context object
    """
    # Get user rating
    rating = int(update.message.text)

    # Save rating to user data
    context.user_data["rating"] = rating

    # Ask user to leave a text review
    await context.bot.send_message(
        chat_id=update.effective_chat.id,
        text=Replies.LEAVE_REVIEW
    )

    return 2


async def process_review_handler(update: Update, context: CallbackContext.DEFAULT_TYPE):
    """Handler that processes a text review by user
    
    Args:
        update: object that represents an incoming update
        context: a context object
    """
    # Get user review
    review = update.message.text

    # Create cursor
    cursor = conn.cursor()

    # Save review to the database
    cursor.execute("INSERT INTO reviews (review, rating, cafe_id) VALUES (?, ?, ?)", 
                   (review, context.user_data["rating"], context.user_data["rating_cafe_id"],))
    conn.commit()

    # Close cursor
    cursor.close()

    # Send thank you text
    await context.bot.send_message(
        chat_id=update.effective_chat.id,
        text=Replies.THANKS_FOR_REVIEW
    )

    # End the conversation
    return ConversationHandler.END


async def read_reviews_handler(update: Update, context: CallbackContext.DEFAULT_TYPE):
    """Handler which shows reviews for specified cafe
    
    Args:
        update: object that represents an incoming update
        context: a context object
    """
    # Get cafe id from callback query
    cafe_id = int(update.callback_query.data.split(":")[1])

    # Create cursor
    cursor = conn.cursor()

    # Get 10 recent reviews from database
    reviews: List[Review] = list(map(lambda x: Review(*x), 
                        cursor.execute("SELECT * FROM reviews WHERE cafe_id = ? ORDER BY id DESC LIMIT 10", 
                                        (cafe_id,))))
    # Get cafe
    cafe = Cafe(*next(cursor.execute("SELECT * FROM cafes WHERE id = ?", (cafe_id,))))

    # Close cursor
    cursor.close()

    if len(reviews) == 0:
        await context.bot.send_message(
            chat_id=update.effective_chat.id,
            text=Replies.NO_REVIEWS
        )
    else:
        # Show recent reviews to the user
        await context.bot.send_message(
            chat_id=update.effective_chat.id,
            text=Templates.RECENT_REVIEWS_TEMPLATE.format(cafe.title, '\n\n'.join(
                Templates.REVIEW_ROW_TEMPLATE.format(rev.rating, rev.review) for rev in reviews
            ))
        )
    