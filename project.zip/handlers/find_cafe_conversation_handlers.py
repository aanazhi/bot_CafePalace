from telegram import InlineKeyboardButton, InlineKeyboardMarkup, Update, Location
from telegram.ext import CallbackContext, ConversationHandler

from constants import conn
from classes import Cafe
from replies import Replies, Templates

from typing import List, Tuple

from utils import send_cafes


async def choose_district_handler(update: Update, context: CallbackContext.DEFAULT_TYPE):
    """Handler for '🍽 Подобрать заведение' text
    which provides user with the ability to choose district

    Args:
        update: object that represents an incoming update
        context: a context object
    """
    # Create new cursor for database connection
    cursor = conn.cursor()

    # Find all districts in database
    districts = list(cursor.execute("SELECT DISTINCT district FROM cafes ORDER BY district"))

    # Close cursor
    cursor.close()

    # Create inline keyboard
    keyboard: List[List[InlineKeyboardButton]] = []
    for i in range(len(districts)):
        if i % 2 == 0:
            keyboard.append([])
        keyboard[-1].append(InlineKeyboardButton(districts[i][0], callback_data=districts[i][0]))
    # Send message to user
    await context.bot.send_message(
        chat_id=update.effective_chat.id, 
        text=Replies.CHOOSE_DISTRICT,
        reply_markup=InlineKeyboardMarkup(keyboard)
    )

    # Return code for the next handler in conversation
    return 1


async def choose_average_price_handler(update: Update, context: CallbackContext.DEFAULT_TYPE):
    """Handler which processes chosen district 
    and asks user for preferrable average price

    Args:
        update: object that represents an incoming update
        context: a context object
    """
    # Get district name
    district = update.callback_query.data

    # Save chosen district to users' context
    context.user_data["district"] = district

    # Create keyboard with average prices
    prices = ["0 - 800₽", "800 - 1500₽", "1500 - 2500₽"]
    keyboard: List[List[InlineKeyboardButton]] = [
        [InlineKeyboardButton(price, callback_data=f"[avg_price]:{price}")] for price in prices
    ]

    # Send message which asks user to choose the price
    await context.bot.send_message(
        chat_id=update.effective_chat.id,
        text=Replies.CHOOSE_AVG_PRICE,
        reply_markup=InlineKeyboardMarkup(keyboard)
    )
    return 2


async def choose_cuisine_handler(update: Update, context: CallbackContext.DEFAULT_TYPE):
    """Handler which processes chosen average price
    and asks user for preferrable cuisine

    Args:
        update: object that represents an incoming update
        context: a context object
    """
    # Get chosen average price
    average_price = update.callback_query.data.split(":")[1]
    print(average_price)
    # Save average price to users' context
    context.user_data["avg_price"] = average_price

    # Create cursor
    cursor = conn.cursor()

    # Get all cuisine types from database
    cuisine: List[Tuple[str]] = list(cursor.execute("SELECT DISTINCT cuisine FROM cafes ORDER BY cuisine"))

    # Close cursor
    cursor.close()

    # Create inline keyboard
    keyboard: List[List[InlineKeyboardButton]] = []
    for i in range(len(cuisine)):
        if i % 2 == 0:
            keyboard.append([])
        keyboard[-1].append(InlineKeyboardButton(cuisine[i][0], callback_data=cuisine[i][0]))
    
    # Send message with user data
    await context.bot.send_message(
        chat_id=update.effective_chat.id,
        text=Replies.CHOOSE_PREFERABLE_CUISINE,
        reply_markup=InlineKeyboardMarkup(keyboard)
    )

    return 3


async def show_cafes_handler(update: Update, context: CallbackContext.DEFAULT_TYPE):
    """Handler that processes users' data 
    and lists cafes based on preferences
    
    Args:
        update: object that represents an incoming update
        context: a context object
    """
    # Get chosen cuisine
    cuisine = update.callback_query.data

    # Get lower and upper bound for preferrable prices
    price_lower_bound, price_upper_bound = list(map(lambda x: int(x.strip().strip("₽")), context.user_data["avg_price"].split(" - ")))

    # Create cursor
    cursor = conn.cursor()

    # Get cafes that meet specified criteria
    cafes: List[Cafe] = list(map(lambda x: Cafe(*x), cursor.execute("""SELECT * FROM cafes 
    WHERE avg_price >= ? 
    AND avg_price <= ? 
    AND district = ? 
    AND cuisine = ?""", (price_lower_bound, price_upper_bound, context.user_data["district"], cuisine,))))

    # Send information about found cafes
    if len(cafes):
        await send_cafes(update, context, cursor, cafes)
    else:
        await context.bot.send_message(
            chat_id=update.effective_chat.id,
            text=Replies.NO_RESULTS
        )

    # Close cursor
    cursor.close()

    return ConversationHandler.END


async def show_location_handler(update: Update, context: CallbackContext.DEFAULT_TYPE):
    """Handler which sends user a location of cafe
    
    Args:
        update: object that represents an incoming update
        context: a context object
    """
    # Get cafe id
    cafe_id = int(update.callback_query.data.split(":")[1])

    # Create cursor
    cursor = conn.cursor()

    # Get cafe from database
    cafe = Cafe(*next(cursor.execute("SELECT * FROM cafes WHERE id = ?", (cafe_id,))))

    # Close cursor
    cursor.close()

    # Send the location of restaurant
    await context.bot.send_message(
        chat_id=update.effective_chat.id,
        text=f'🍽 "{cafe.title}" находится здесь:'
    )
    await context.bot.send_location(
        chat_id=update.effective_chat.id,
        location=Location(cafe.longitude, cafe.latitude)
    )
