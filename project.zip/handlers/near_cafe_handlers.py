from telegram import InlineKeyboardButton, InlineKeyboardMarkup, Update, Location
from telegram.ext import CallbackContext, ConversationHandler

from constants import conn
from classes import Point, Cafe
from replies import Replies, Templates

from typing import List, Tuple

from utils import send_cafes


async def nearby_cafes_handler(update: Update, context: CallbackContext.DEFAULT_TYPE):
    """Handler which asks user for the location
    
    Args:
        update: object that represents an incoming update
        context: a context object
    """
    # Send message asking for users' location
    await context.bot.send_message(
        chat_id=update.effective_chat.id,
        text=Replies.ASK_FOR_LOCATION
    )


async def location_handler(update: Update, context: CallbackContext.DEFAULT_TYPE):
    """Handler which processes users' location and finds cafes in radius of 1km
    
    Args:
        update: object that represents an incoming update
        context: a context object
    """
    # Coordinates of user
    user_location = Point(update.message.location.latitude, update.message.location.longitude)

    # Create cursor
    cursor = conn.cursor()

    # Get all cafes from database
    cafes: List[Tuple[Cafe, Point]] = list(map(lambda x: (Cafe(*x), Point(x[6], x[7])), cursor.execute("SELECT * FROM cafes")))

    # Iterate over cafes to find which are in range of 1 km
    nearby_cafes: List[Cafe] = []
    for cafe, point in sorted(cafes, key=lambda x: user_location - x[1]):
        dist = user_location - point
        if dist <= 1:
            cafe.title += f" - {round((user_location - point) * 1000)} м. от вас"
            nearby_cafes.append(cafe)

    await send_cafes(update, context, cursor, nearby_cafes)

    # Close cursor
    cursor.close()