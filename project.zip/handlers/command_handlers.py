from telegram import Update, KeyboardButton, ReplyKeyboardMarkup
from telegram.ext import CallbackContext

from replies import Replies

from typing import List


async def start_handler(update: Update, context: CallbackContext.DEFAULT_TYPE):
    """Handler for /start command
    
    Args:
        update: object that represents an incoming update
        context: a context object
    """
    keyboard: List[List[KeyboardButton]] = [
        [KeyboardButton("🍽 Подобрать заведение")],
        [KeyboardButton("🧭 Поблизости")],
        [KeyboardButton("👥 О нас")]
    ]
    await context.bot.send_message(
        chat_id=update.effective_chat.id, 
        text=Replies.START_REPLY,
        reply_markup=ReplyKeyboardMarkup(keyboard, resize_keyboard=True)
    )